/** Contains code that provides functionality to
 *  activity_create_profile_now.xml (Launching an activity to
 *  create a profile now or going straight to the home screen)
 *
 *  It is not fully implemented as the home screen is not yet fully implemented
 * @author Madison Pickering
 * 4/4/19
 */
package com.example.sheltersheets;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class CreateProfileNow extends AppCompatActivity {

    Intent user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_profile_now);
        user = getIntent();
    }

    public void createProfileNow(View v)
    {
        //launch activity to create a profile now
        Intent createProfile = new Intent(this, DonorProfile.class);
        createProfile.putExtra(MainActivity.NEW_USER, user.getParcelableExtra(MainActivity.NEW_USER));
        startActivity(createProfile);
    }

    public void dontCreateProfileNow(View v)
    {
        //go straight to home screen

    }



}
